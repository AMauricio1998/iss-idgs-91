<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <center>
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                <?php echo e(__('Administracion de usuarios')); ?>

            </h2>
        </center>
     <?php $__env->endSlot(); ?>

    <div class="min-h-screen bg-white py-5">
        
        <?php echo $__env->make('dashboard.partials.session-flash-status', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class='overflow-x-auto w-full'>
            <div class="mx-32 py-2" id="proccess">
                <a 
                    href="<?php echo e(route('usuario-create')); ?>"
                    class="text-white bg-gray-800 hover:bg-gray-900 focus:outline-none focus:ring-4 focus:ring-gray-300 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 dark:bg-gray-800 dark:hover:bg-gray-700 dark:focus:ring-gray-700 dark:border-gray-700"
                >
                    Nuevo usuario
                </a>
                
                <a 
                    href="<?php echo e(route('excel-usuarios')); ?>"
                    class="text-white bg-green-800 hover:bg-green-900 focus:outline-none focus:ring-4 focus:ring-green-300 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 dark:bg-green-800 dark:hover:bg-green-700 dark:focus:ring-green-700 dark:border-green-700"
                >
                    Generar excel <i class="fa-solid fa-file-excel"></i>
                </a>
            </div>
            <table class='mt-2 mx-auto max-w-4xl w-full whitespace-nowrap rounded-lg bg-white divide-y divide-gray-300 overflow-hidden'>
                <thead class="bg-gray-900">
                    <tr class="text-white text-left">
                        <th class="font-semibold text-sm uppercase px-6 py-4"> Name </th>
                        <th class="font-semibold text-sm uppercase px-6 py-4 text-center"> Telefono </th>
                        <th class="font-semibold text-sm uppercase px-6 py-4 text-center"> Area </th>
                        <th class="font-semibold text-sm uppercase px-6 py-4 text-center"> rol </th>
                        <th class="font-semibold text-sm uppercase px-6 py-4 text-center"> Fecha de alta </th>
                        <th class="font-semibold text-sm uppercase px-6 py-4 text-center"> status </th>
                        <th class="font-semibold text-sm uppercase px-6 py-4 text-center"> Opciones </th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                    <?php $__empty_1 = true; $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="px-6 py-4">
                                <div class="flex items-center space-x-3">
                                    <div>
                                        <p> <?php echo e($usu->name); ?> <?php echo e($usu->app); ?> </p>
                                        <p class="text-gray-500 text-sm font-semibold tracking-wide"> <?php echo e($usu->email); ?> </p>
                                    </div>
                                </div>
                            </td>
                            <td class="px-6 py-4">
                                <p class=""> <?php echo e($usu->telefono); ?> </p>
                            </td>
                            <td class="px-6 py-4 text-center"> <?php echo e($usu->areas->nombre_area); ?> </td>
                            <td class="px-6 py-4 text-center"> <?php echo e($usu->roles->nombre_rol); ?> </td>
                            <td class="px-6 py-4 text-center"> <?php echo e($usu->created_at->format('d-m-Y')); ?> </td>
                            <td class="px-6 py-4 text-center"> 
                                <span 
                                    class="text-white text-sm w-1/3 pb-1 bg-<?php echo e($usu->status == '1' ? 'green-600' : 'red-700'); ?> font-semibold px-2 rounded-full"
                                > 
                                    <?php echo e($usu->status == '1' ? 'Activo' : 'Inactivo'); ?>

                                </span> 
                            </td>
                            <td class="px-6 py-4 text-center flex flex-row"> 
                                <a 
                                    href="<?php echo e(route('usuario-show', $usu->id)); ?>" 
                                    class="bg-green-500 font-bold py-2 px-2 rounded-lg flex flex-raw mx-1"
                                    title="Ver"
                                >
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                                    </svg>
                                </a>

                                <a 
                                href="<?php echo e(route('usuario-edit', $usu->id)); ?>" 
                                class="bg-blue-500 font-bold py-2 px-2 rounded-lg flex flex-raw mx-1"
                                    title="Editar"
                                >
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                                    </svg>
                                </a>

                                <form
                                    method="POST"
                                    action="<?php echo e(route('usuario-proccess', $usu->id)); ?>"
                                    class="bg-indigo-200 font-bold py-2 px-2 rounded-lg flex flex-raw mx-1 approved"
                                    title="<?php echo e($usu->status == '1' ? 'Desactivar' : 'Activar'); ?>"
                                >
                                <?php echo csrf_field(); ?>
                                    <button type="submit">
                                        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                            <path stroke-linecap="round" stroke-linejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                                        </svg>
                                    </button>
                                </form>

                                <?php if(auth()->user()->id == $usu->id): ?>

                                <?php else: ?>
                                    <form action="<?php echo e(route('usuario-destroy', $usu->id)); ?>" 
                                        class="bg-red-500 font-bold py-2 px-2 rounded-lg flex flex-raw mx-1 hover:bg-red-400"
                                        method="POST" name="borrar">
                                        <?php echo csrf_field(); ?>
                                        <?php echo e(method_field('DELETE')); ?>

                                        <button type="submit" title="Eliminar">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                <path stroke-linecap="round" stroke-linejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                              </svg>
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        
                    <?php endif; ?>
                </tbody>
            </table>

            <center>
                <?php echo e($usuarios->links()); ?>

            </center>

        </div>
    </div>

    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\papeleria\resources\views/dashboard/usuarios/index.blade.php ENDPATH**/ ?>