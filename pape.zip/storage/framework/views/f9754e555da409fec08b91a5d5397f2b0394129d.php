
                <table class='mt-2 mx-auto max-w-4xl w-full whitespace-nowrap rounded-lg bg-white divide-y divide-gray-300 overflow-hidden'>
                    <thead class="bg-gray-900">
                        <tr class="text-white text-left">
                            <th class="font-semibold text-sm uppercase px-6 py-4"> # </th>
                            <th class="font-semibold text-sm uppercase px-6 py-4"> Codigo solicitud </th>
                            <th class="font-semibold text-sm uppercase px-6 py-4 text-center"> Status </th>
                            <th class="font-semibold text-sm uppercase px-6 py-4 text-center"> Quien Solicita </th>
                            <th class="font-semibold text-sm uppercase px-6 py-4 text-center"> Area </th>
                            <th class="font-semibold text-sm uppercase px-2 py-4 text-center"> Producto </th>
                            <th class="font-semibold text-sm uppercase px-2 py-4 text-center"> Num. Productos </th>
                            <th class="font-semibold text-sm uppercase px-6 py-4 text-center"> Fecha de creación </th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        <?php $__empty_1 = true; $__currentLoopData = $solicitudes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $solicitud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="px-6 py-4"><?php echo e($solicitud->id_solicitud); ?></td>
                                <td class="px-6 py-4"><?php echo e($solicitud->codigo_solicitud); ?></td>
                                <td class="px-6 py-4 text-center"> <?php echo e($solicitud->nombre_status); ?></td>
                                <td class="px-6 py-4 text-center"> <?php echo e($solicitud->name); ?> <?php echo e($solicitud->app); ?> <?php echo e($solicitud->apm); ?></td>
                                <td class="px-6 py-4 text-center"> <?php echo e($solicitud->nombre_area); ?> </td>
                                <td class="px-6 py-4 text-center"> <?php echo e($solicitud->nombre_producto); ?> </td>
                                <td class="px-6 py-4 text-center"><?php echo e($solicitud->cantidad); ?></td>
                                <td class="px-6 py-4 text-center"> <?php echo e($solicitud->created_at); ?> </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            
                        <?php endif; ?>
                    </tbody>
                </table><?php /**PATH C:\laragon\www\papeleria\resources\views/dashboard/excel/solicitudes-excel.blade.php ENDPATH**/ ?>