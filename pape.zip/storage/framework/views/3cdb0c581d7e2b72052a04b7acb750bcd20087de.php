<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <center>
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                <?php echo e(__('Detalle de la solicitud')); ?>

            </h2>
        </center>
     <?php $__env->endSlot(); ?>
        
            <?php echo $__env->make('dashboard.partials.session-flash-status', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php if(Session::has('msg1')): ?>
                <div class="bg-green-500 font-bold text-white w-auto text-center" role="alert">
                    <?php echo e(Session::get('msg1')); ?>

                </div>
            <?php endif; ?>
            <?php if(Session::has('msg2')): ?>
                <div class="bg-green-500 font-bold text-white w-auto text-center" role="alert">
                    <?php echo e(Session::get('msg2')); ?>

                </div>
            <?php endif; ?>
    
                <div class="flex flex-row justify-evenly mt-2 w-auto">
                    <div class="w-auto">
                        <h3 class="font-semibold my-1">Datos de la solicitud</h3>
                        <?php $__currentLoopData = $sol; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $soli): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <h4><span class="font-semibold">Codigo del producto: </span><?php echo e($soli->codigo_solicitud); ?></h4>
                            <h4><span class="font-semibold">Fecha de creacion: </span><?php echo e(\Carbon\Carbon::parse($soli->created_at )->format('Y-m-d')); ?></h4>

                            <?php if($soli->id_status == 3): ?>
                                <h4><span class="font-semibold">Estatus: </span><?php echo e($soli->nombre_status); ?></h4>
                            <?php endif; ?>

                            <?php if($soli->id_status == 1 || $soli->id_status == 2): ?>
                                <form action="<?php echo e(route('modificar-solicitud',['id'=>$soli->codigo_solicitud])); ?>" method="POST" name="nuevo" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <?php echo e(method_field('PUT')); ?>

                                    <h4 class="font-semibold">Estatus: 
                                    <select 
                                        name="id_status" 
                                        id="id_status"
                                        class="w-60 px-3 py-1 rounded-lg appearance-none text-base font-normal text-gray-700 bg-white bg-clip-padding bg-no-repeat border border-solid border-gray-300 transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none"
                                    >
                                        <option value="">-- Selecciona el estatus --</option>
                                        <?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($estado->id); ?>"><?php echo e($estado->nombre_status); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    </h4>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="w-auto"> 
                        <h3 class="font-semibold my-1">Datos del usuario</h3>
                        <?php $__currentLoopData = $sol; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $solicita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <h4><span class="font-semibold">Nombre: </span><?php echo e($solicita->name); ?> <?php echo e($solicita->app); ?> <?php echo e($solicita->apm); ?></h4>
                            <h4><span class="font-semibold">Email: </span><?php echo e($solicita->email); ?></h4>
                            <h4><span class="font-semibold">Telefono: </span><?php echo e($solicita->telefono); ?></h4>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </div>

                <center>
                    <div class='overflow-x-auto w-full'>
                        <table class='mt-2 mx-auto max-w-4xl w-full whitespace-nowrap rounded-lg bg-white divide-y divide-gray-300 overflow-hidden'>
                            <thead class="bg-gray-900">
                                <tr class="text-white text-left">
                                    <th class="font-semibold text-sm uppercase px-6 py-4"> Codigo producto </th>
                                    <th class="font-semibold text-sm uppercase px-6 py-4 text-center"> Nombre Producto </th>
                                    <th class="font-semibold text-sm uppercase px-6 py-4 text-center"> Cantidad </th>
                                    <th class="font-semibold text-sm uppercase px-6 py-4 text-center"> Categoria </th>
                                    <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($detalle->id_status == 2): ?>
                                            <th class="font-semibold text-sm uppercase px-6 py-4 text-center"> Verificacion </th>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-200 border-collapse border-emerald-900">
                                <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="px-6 py-4">
                                            <div class="flex items-center space-x-3">
                                                <div>
                                                    <p> <?php echo e($detalle->codigo_solicitud); ?></p>
                                                </div>
                                            </div>
                                        </td>

                                        <td class="px-6 py-4 text-center">
                                            <p class=""> <?php echo e($detalle->nombre_prod); ?> </p>
                                        </td>
                                        <td class="px-6 py-4 text-center"> <?php echo e($detalle->cantidad); ?> </td>
                                        <td class="px-6 py-4 text-center"> <?php echo e($detalle->nombre_categoria); ?> </td>
                                        <?php if($detalle->id_status == 2): ?>
                                            <td class="px-6 py-4 text-center"> 
                                                <div id="prueba">
                                                    <input 
                                                        class="form-check-input appearance-none h-4 w-4 border border-gray-300 rounded-sm bg-white checked:bg-blue-600 checked:border-blue-600 focus:outline-none transition duration-200 mt-1 align-top bg-no-repeat bg-center bg-contain float-none mr-2 cursor-pointer"
                                                        type="checkbox"
                                                        name="nombres[]"
                                                        value="<?php echo e($detalle->id); ?>,<?php echo e($detalle->cantidad); ?>" 
                                                        id="flexCheckDefault<?php echo e($detalle->id); ?>"
                                                    >
                                                </div>
                                            </td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div class="max-w-4xl w-full flex flex-row justify-between border-2 border-gray-200 bg-gray-100 rounded-lg py-2 px-2">
                            <div class="font-bold text-lg mx-6">Total</div>
                            <div class="font-bold text-lg mx-6"><?php echo e($total->Total); ?> productos</div>
                        </div>
                        <div class="max-w-4xl w-full flex flex-row justify-between bg-gray-100 rounded-lg py-2 px-2">
                            <div class="font-bold text-lg mx-6">
                                <a 
                                    href="<?php echo e(route('solicitudes-index')); ?>"
                                    class="text-white bg-gradient-to-r from-red-400 via-red-500 to-red-600 hover:bg-gradient-to-br focus:ring-4 focus:outline-none focus:ring-red-300 dark:focus:ring-red-800 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2">
                                    Cancelar
                                </a>
                            </div>
                            <div class="font-bold text-lg mx-6">
                                <input type="submit" value="Guardar" class="text-white bg-gradient-to-r from-blue-500 via-blue-600 to-blue-700 hover:bg-gradient-to-br focus:ring-4 focus:outline-none focus:ring-blue-300 dark:focus:ring-blue-800 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2" />
                            </div>
                        </div>
                        <hr class="max-w-4xl w-full flex flex-row justify-between bg-gray-700 rounded-lg py-0">
                    </div>
                </center>
            </form>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\papeleria\resources\views/dashboard/solicitudes/detalle_solicitud.blade.php ENDPATH**/ ?>