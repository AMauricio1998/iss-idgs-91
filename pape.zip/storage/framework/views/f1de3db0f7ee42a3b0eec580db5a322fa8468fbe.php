<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <center>
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                Listado de productos 
            </h2>
        </center>
     <?php $__env->endSlot(); ?>

    <div class="min-h-screen bg-white py-5">
        <?php if(Session::has('add-producto')): ?>
            <div class="bg-green-400 font-bold uppercase text-white text-center" role="alert">
                <?php echo e(Session::get('add-producto')); ?>

            </div>
        <?php endif; ?>
        <div class='overflow-x-auto w-full'>
        <div aria-label="group of cards" tabindex="0" class="focus:outline-none py-8 w-full">
            <div class="lg:flex flex-col items-center justify-center w-full">
                <form action="<?php echo e(route('nueva-solicitud')); ?>">
                    <div class="relative md:block w-auto">
                        <button type="submit" class="flex absolute inset-y-0 left-0 items-center pl-3">
                                <i class="fa-solid fa-magnifying-glass"></i>
                        </button>
                        <input type="text" id="search" name="search" value="<?php echo e(request('search')); ?>" class="block p-2 pl-10 w-full text-gray-900 bg-gray-50 rounded-lg border border-gray-300 sm:text-sm focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="Search...">
                    </div>
                </form>
                <?php $__empty_1 = true; $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div tabindex="0" aria-label="card 1" class="focus:outline-none lg:w-1/2 mt-3 lg:mr-7 lg:mb-0 mb-7 bg-white dark:bg-gray-800  p-6 shadow rounded">
                        <div class="flex items-center border-b border-gray-200 dark:border-gray-700  pb-6">
                            <img src="https://cdn.tuk.dev/assets/components/misc/doge-coin.png" alt="coin avatar" class="w-12 h-12 rounded-full" />
                            <div class="flex items-start justify-between w-full">
                                <div class="pl-3 w-full">
                                    <p tabindex="0" class="focus:outline-none text-xl font-medium leading-5 text-gray-800 dark:text-white "><?php echo e($producto->nombre); ?></p>
                                    <p tabindex="0" class="focus:outline-none text-sm leading-normal pt-2 text-gray-500 dark:text-gray-200 "><?php echo e($producto->stock); ?> <?php echo e($producto->unidades->nombre); ?>-<?php echo e($producto->unidades->abreviatura); ?></p>
                                </div>
                                <div role="img" aria-label="bookmark">
                                    <a href="<?php echo e(route('add-producto',['id' => $producto->id]  )); ?>">
                                        <i class="fa-solid fa-cart-plus fa-xl"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="px-2">
                            <p tabindex="0" class="focus:outline-none text-sm leading-5 py-4 text-gray-600 dark:text-gray-200 "><?php echo e($producto->descripcion); ?></p>
                            <div tabindex="0" class="focus:outline-none flex">
                                <div class="py-2 px-4 text-xs leading-3 text-indigo-700 rounded-full bg-indigo-100">#<?php echo e($producto->categorias->nombre); ?></div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <span class="font-bold bg-red-400 text-center text-white">No hay productos</span>
                <?php endif; ?>
                <?php if(isset($solicitud)): ?>
                    <?php $__currentLoopData = $solicitud; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $soli): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a
                        href="<?php echo e(route('mostrar-carrito', $soli->codigo_solicitud)); ?>"
                            class="bg-blue-500 mt-2 py-1 px-1 font-semibold rounded-lg border-2 border-gray-300 text-white hover:bg-blue-700"
                        >
                            Mostrar Carrito
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\papeleria\resources\views/users/solicitudes/nueva_solicitud.blade.php ENDPATH**/ ?>