            <table class='mt-2 mx-auto max-w-4xl w-full whitespace-nowrap rounded-lg bg-white divide-y divide-gray-300 overflow-hidden'>
                <thead class="bg-gray-900">
                    <tr class="text-white text-left">
                        <th class="font-semibold text-sm uppercase px-6 py-4"> Nombre </th>
                        <th class="font-semibold text-sm uppercase px-6 py-4 text-center"> Telefono </th>
                        <th class="font-semibold text-sm uppercase px-6 py-4 text-center"> Colonia </th>
                        <th class="font-semibold text-sm uppercase px-6 py-4 text-center"> Calle </th>
                        <th class="font-semibold text-sm uppercase px-6 py-4 text-center"> Num. calle </th>
                        <th class="font-semibold text-sm uppercase px-6 py-4 text-center"> Cod. postal </th>
                        <th class="font-semibold text-sm uppercase px-6 py-4 text-center"> Estado </th>
                        <th class="font-semibold text-sm uppercase px-6 py-4 text-center"> Municipio </th>
                        <th class="font-semibold text-sm uppercase px-6 py-4 text-center"> Email </th>
                        <th class="font-semibold text-sm uppercase px-6 py-4 text-center"> Area </th>
                        <th class="font-semibold text-sm uppercase px-6 py-4 text-center"> rol </th>
                        <th class="font-semibold text-sm uppercase px-6 py-4 text-center"> Fecha de alta </th>
                        <th class="font-semibold text-sm uppercase px-6 py-4 text-center"> status </th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                    <?php $__empty_1 = true; $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="px-6 py-4"> <?php echo e($usu->name); ?> <?php echo e($usu->app); ?> <?php echo e($usu->apm); ?></td>
                            <td class="px-6 py-4"><?php echo e($usu->telefono); ?></td>
                            <td class="px-6 py-4"><?php echo e($usu->colonia); ?></td>
                            <td class="px-6 py-4"><?php echo e($usu->calle); ?></td>
                            <td class="px-6 py-4"><?php echo e($usu->num_calle); ?></td>
                            <td class="px-6 py-4"><?php echo e($usu->cod_postal); ?></td>
                            <td class="px-6 py-4"><?php echo e($usu->estado); ?></td>
                            <td class="px-6 py-4"><?php echo e($usu->municipio); ?></td>
                            <td class="px-6 py-4"><?php echo e($usu->email); ?></td>
                            <td class="px-6 py-4"> <?php echo e($usu->areas->nombre_area); ?> </td>
                            <td class="px-6 py-4"> <?php echo e($usu->roles->nombre_rol); ?> </td>
                            <td class="px-6 py-4"> <?php echo e($usu->created_at->format('d-m-Y')); ?> </td>
                            <td class="px-6 py-4"> 
                                <span 
                                    class="text-white text-sm w-1/3 pb-1 bg-<?php echo e($usu->status == '1' ? 'green-600' : 'red-700'); ?> font-semibold px-2 rounded-full"
                                > 
                                    <?php echo e($usu->status == '1' ? 'Activo' : 'Inactivo'); ?>

                                </span> 
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        
                    <?php endif; ?>
                </tbody>
            </table><?php /**PATH C:\laragon\www\papeleria\resources\views/dashboard/excel/usuarios-excel.blade.php ENDPATH**/ ?>